package com.example.panwangliang.mygrades;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private DBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        db= new DBHelper(this);
        Bundle bundle = getIntent().getExtras();
        Intent intent = getIntent();
        if(intent.hasExtra("deletetype")){
            List<Class> dbclasses= db.getAllClasses();
            List<Assignment> dbassignments= db.getAllAssignments();
            List<Category> dbcategories=db.getAllCategories();

            if(bundle.getString("deletetype").equals("assignment")){
                for(int i=0;i<dbassignments.size();i++){
                    if (dbassignments.get(i).getClassName().equals(bundle.getString("whatclass")) && dbassignments.get(i).getAssignmentname().equals(bundle.getString("assignmentname")) && dbassignments.get(i).getCategoryName().equals(bundle.getString("whatcategory"))){
                        db.deleteFromAssignments(""+dbassignments.get(i).getID());
                    }
                }

            }
            if(bundle.getString("deletetype").equals("category")){
                for(int i=0;i<dbcategories.size();i++){
                    if(dbcategories.get(i).getClassname().equals(bundle.getString("whatclass"))&&dbcategories.get(i).getCategoryName().equals(bundle.getString("categoryname"))){
                        db.deleteFromCategories(""+dbcategories.get(i).getID());
                    }
                }

            }
            if(bundle.getString("deletetype").equals("class")){
                for(int i=0;i<dbclasses.size();i++){
                    if(dbclasses.get(i).getClassName().equals(bundle.getString("classname"))){
                        db.deleteFromClasses(""+dbclasses.get(i).getID());
                    }
                }

            }
            List<Class> classlist = organizeData();
            if(classlist.size()>0) {
                if (classlist.get(0).getcategorylist().size() > 0) {
                    if (classlist.get(0).getcategorylist().get(0).getAssignmentlist().size() > 0) {
                        showGrades(classlist);
                    }
                }
            }
        }
        if(intent.hasExtra("type")) {
            if (bundle.getString("type").equals("assignment")) {
                db.addAssignment(bundle.getString("assignmentname"), bundle.getString("whatclass"), bundle.getString("whatcategory"), bundle.getDouble("earnedpoints"), bundle.getDouble("possiblepoints"));
            }
            if(bundle.getString("type").equals("category")){
                db.addCategory(bundle.getString("categoryname"), bundle.getDouble("categoryworth")*.01,bundle.getString("whatclass"));
            }
            if(bundle.getString("type").equals("class")){
                db.addClass(bundle.getString("classname"));
            }
            List<Class> classlist = organizeData();
            if(classlist.size()>0) {
                if (classlist.get(0).getcategorylist().size() > 0) {
                    if (classlist.get(0).getcategorylist().get(0).getAssignmentlist().size() > 0) {
                        showGrades(classlist);
                    }
                }
            }


        }
        List<Class> classlist = organizeData();
        if(classlist.size()>0) {
            if (classlist.get(0).getcategorylist().size() > 0) {
                if (classlist.get(0).getcategorylist().get(0).getAssignmentlist().size() > 0) {
                    showGrades(classlist);
                }
            }
        }






    }

    public void toDeleteScreen(View view){
        Intent intent = new Intent(this, DeleteScreen.class);
        startActivity(intent);
    }


    public void toAddScreen(View view){
        Intent intent = new Intent(this, AddScreen.class);
        startActivity(intent);


    }

    public List<Class> organizeData(){

        List<Class> finalclasslist = db.getAllClasses();
        List<Assignment> finalassignmentlist = db.getAllAssignments();
        List<Category> finalcategorylist = db.getAllCategories();

        if(finalclasslist.size()>0 && finalassignmentlist.size()>0 && finalcategorylist.size()>0){

            for(int i=0;i<finalcategorylist.size();i++){
              List<Assignment> tempassignmentlist = new ArrayList<Assignment>();
              for(int j=0;j<finalassignmentlist.size();j++){
                 if(finalassignmentlist.get(j).getClassName().equals(finalcategorylist.get(i).getClassname()) && finalassignmentlist.get(j).getCategoryName().equals(finalcategorylist.get(i).getCategoryName())){
                        tempassignmentlist.add(finalassignmentlist.get(j));
                    }
             }
              finalcategorylist.get(i).setAssignmentlist(tempassignmentlist);
            }

            for(int i=0;i<finalclasslist.size();i++){
              List<Category> tempcategorylist= new ArrayList<Category>();
              for(int j=0;j<finalcategorylist.size();j++){
                 if(finalcategorylist.get(j).getClassname().equals(finalclasslist.get(i).getClassName())){
                       tempcategorylist.add(finalcategorylist.get(j));
                 }
               }
                finalclasslist.get(i).setCategorylist(tempcategorylist);
           }
        }
        return finalclasslist;







    }

    public void showGrades(List<Class> classlist){
        setContentView(R.layout.activity_main);
        LinearLayout ll = findViewById(R.id.linearlayout);
        for(int i=0;i<classlist.size();i++){
            Class thisclass = classlist.get(i);
            TextView tempview = new TextView(this);
            String grade = "";
            grade+=thisclass.getClassName()+ ": "+thisclass.returnGrade()+"\n";
            for(int j=0;j<thisclass.getcategorylist().size();j++){
                Category thiscategory = thisclass.getcategorylist().get(j);
                grade+= "    -"+ thiscategory.getCategoryName()+ "("+(double)Math.round(((thiscategory.getTotalEarnedPoints()/thiscategory.getTotalPoints())*100)*100)/100+"%)"+"\n";
                for(int k=0;k<thiscategory.getAssignmentlist().size();k++){
                    Assignment a = thiscategory.getAssignmentlist().get(k);
                    grade+= "       -"+a.getAssignmentname()+ ": "+a.getEarnedpoints()+"/"+a.getTotalpoints()+"\n";
                }
            }
            tempview.setText(grade);
            ll.addView(tempview);

        }


    }


    public void toCalculateScreen(View view){
        EditText points = findViewById(R.id.points);
        EditText category = findViewById(R.id.category);
        EditText classview =findViewById(R.id.classview);
        Intent intent = new Intent(this, CalculateScreen.class);
        Bundle bundle = new Bundle();
        ArrayList<Integer> intlist = new ArrayList<Integer>();
        List<Class> classlist = organizeData();
        for(int i=0;i<classlist.size();i++) {
            if(classview.getText().toString().equals(classlist.get(0).getClassName())) {
                if (classlist.get(i).getcategorylist().size() > 0) {
                    if (classlist.get(i).getcategorylist().get(0).getAssignmentlist().size() > 0) {
                        for (int j = 1; j <= 100; j++) {
                            intlist.add(classlist.get(i).returnRequiredGrade(Integer.parseInt((points.getText().toString())), category.getText().toString(), j));
                        }
                    }
                }
            }
        }
        bundle.putInt("max",Integer.parseInt(points.getText().toString()));
        bundle.putIntegerArrayList("intlist",intlist);
        intent.putExtras(bundle);


        startActivity(intent);
    }






}
