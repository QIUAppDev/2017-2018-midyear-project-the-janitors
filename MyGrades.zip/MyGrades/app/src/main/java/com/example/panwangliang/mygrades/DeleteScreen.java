package com.example.panwangliang.mygrades;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class DeleteScreen extends AppCompatActivity {
    private EditText categoryname, assignmentname, classname, whatclass,whatcategory;
    private Button addCategory, addAssignment, addClass, delete;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_screen);
        initialize();
    }
    public void initialize(){
        categoryname = findViewById(R.id.categoryName);
        assignmentname = findViewById(R.id.AssignmentName);
        classname = findViewById(R.id.className);
        whatclass = findViewById(R.id.whichClass);
        whatcategory = findViewById(R.id.whichCategory);
        addCategory = findViewById(R.id.addCategory);
        addAssignment = findViewById(R.id.addAssignment);
        addClass = findViewById(R.id.addClass);
        delete = findViewById(R.id.deleteField);
    }

    public void showClass(View view){
        setInvisible();
        classname.setVisibility(View.VISIBLE);
        delete.setVisibility(View.VISIBLE);
    }
    public void showAssignment(View view){
        setInvisible();
        assignmentname.setVisibility(View.VISIBLE);
        whatclass.setVisibility(View.VISIBLE);
        whatcategory.setVisibility(View.VISIBLE);
        delete.setVisibility(View.VISIBLE);

    }
    public void showCategory(View view){
        setInvisible();
        categoryname.setVisibility(View.VISIBLE);
        whatclass.setVisibility(View.VISIBLE);
        delete.setVisibility(View.VISIBLE);

    }

    public void setInvisible(){
        categoryname.setVisibility((View.INVISIBLE));
        assignmentname.setVisibility((View.INVISIBLE));
        classname.setVisibility((View.INVISIBLE));
        whatclass.setVisibility((View.INVISIBLE));
        whatcategory.setVisibility((View.INVISIBLE));
        delete.setVisibility((View.INVISIBLE));

    }

    public void deleteField(View view){
        Bundle bundle = new Bundle();
        Intent intent = new Intent(this,MainActivity.class);
        if(classname.getVisibility()==View.VISIBLE){
            bundle.putString("deletetype", "class");
            bundle.putString("classname",classname.getText().toString());
            intent.putExtras(bundle);
            startActivity(intent);

        }

        if(assignmentname.getVisibility()==View.VISIBLE){
            bundle.putString("deletetype", "assignment");
            bundle.putString("assignmentname",assignmentname.getText().toString());
            bundle.putString("whatcategory",whatcategory.getText().toString());
            bundle.putString("whatclass",whatclass.getText().toString());
            intent.putExtras(bundle);
            startActivity(intent);
        }

        if(categoryname.getVisibility()==View.VISIBLE){
            Category c = new Category();
            c.setName(categoryname.getText().toString());
            c.setClassName(whatclass.getText().toString());
            bundle.putString("deletetype", "category");
            bundle.putString("categoryname", categoryname.getText().toString());
            bundle.putString("whatclass", whatclass.getText().toString());
            intent.putExtras(bundle);
            startActivity(intent);
        }
    }
}
