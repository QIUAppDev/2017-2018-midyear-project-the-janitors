package com.example.panwangliang.mygrades;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Jason Pan on 1/7/2018.
 */

public class DBHelper extends SQLiteOpenHelper {

    // Database Name
    private static final String DATABASE_NAME = "MyGrades";
    // tasks table name
    private static final String TABLE_CLASSES = "Classes";
    private static final String TABLE_CATEGORIES= "Categories";
    private static final String TABLE_ASSIGNMENTS = "Assignments";
    // classes columns
    private static final String KEY_CLASSNAME = "classname";
    private static final String KEY_CLASSID = "classid";
    //categories columns
    private static final String KEY_CATEGORYNAME = "categoryname";
    private static final String KEY_CATEGORYWORTH = "name";
    private static final String KEY_TOTALEARNEDPOINTS = "totalearnedpoints";
    private static final String KEY_TOTALPOSSIBLEPOINTS = "totalpossiblepoints";
    private static final String KEY_CATEGORYID = "categoryid";

    private static final String KEY_CATEGORYCLASSIDENTIFIER = "categoryclassidentifier";

    //assignment columns
    private static final String KEY_ASSIGNMENTNAME = "assignmentname";
    private static final String KEY_ASSIGNMENTCLASSIDENTIFIER = "assignmentclassidentifier";
    private static final String KEY_ASSIGNMENTCATEGORYIDENTIFIER = "assignmentcategoryidentifier";
    private static final String KEY_EARNEDPOINTS = "earnedpoints";
    private static final String KEY_POSSIBLEPOINTS = "possiblepoints";
    private static final String KEY_ASSIGNMENTID = "assignmentid";


    private static final String CREATE_CLASSES = "CREATE TABLE " + TABLE_CLASSES + "("+ KEY_CLASSID+ " INTEGER PRIMARY KEY AUTOINCREMENT, "+ KEY_CLASSNAME + " TEXT"+")";
    private static final String CREATE_CATEGORIES= "CREATE TABLE " + TABLE_CATEGORIES + "("+ KEY_CATEGORYID+" INTEGER PRIMARY KEY AUTOINCREMENT, " + KEY_CATEGORYNAME+ " TEXT, "+ KEY_CATEGORYWORTH + " REAL, "
            + KEY_CATEGORYCLASSIDENTIFIER + " TEXT" + ")";
    private static final String CREATE_ASSIGNMENTS= "CREATE TABLE " + TABLE_ASSIGNMENTS + "("+ KEY_ASSIGNMENTID +" INTEGER PRIMARY KEY AUTOINCREMENT, " + KEY_ASSIGNMENTNAME + " TEXT, " + KEY_ASSIGNMENTCLASSIDENTIFIER +
            " TEXT, " + KEY_ASSIGNMENTCATEGORYIDENTIFIER + " TEXT, " + KEY_EARNEDPOINTS + " REAL, " + KEY_POSSIBLEPOINTS + " REAL" + ")";







    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }
    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL(CREATE_CLASSES);
        db.execSQL(CREATE_CATEGORIES);
        db.execSQL(CREATE_ASSIGNMENTS);

    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
        // Drop older table if existed
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ASSIGNMENTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CLASSES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CATEGORIES);
        // Create tables again
        onCreate(db);
    }
    // Adding new question
    public void addClass(String name) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_CLASSNAME, name);

        // Inserting Row
        db.insert(TABLE_CLASSES, null, values);
    }

    public void addCategory(String name,Double worth, String classname) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_CATEGORYNAME, name);
        values.put(KEY_CATEGORYWORTH, worth);
        values.put(KEY_CATEGORYCLASSIDENTIFIER, classname);

        // Inserting Row
        db.insert(TABLE_CATEGORIES, null, values);
    }

    public void addAssignment(String name, String classname, String categoryname, double earnedpoints, double possiblepoints) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_ASSIGNMENTNAME, name);
        values.put(KEY_ASSIGNMENTCATEGORYIDENTIFIER, categoryname);
        values.put(KEY_ASSIGNMENTCLASSIDENTIFIER, classname);
        values.put(KEY_EARNEDPOINTS, earnedpoints);
        values.put(KEY_POSSIBLEPOINTS,possiblepoints);

        // Inserting Row
        db.insert(TABLE_ASSIGNMENTS, null, values);
    }



    public List<Class> getAllClasses() {
        SQLiteDatabase db=this.getReadableDatabase();

        List<Class> ClassList = new ArrayList<Class>();
        // Select All Query
        String selectQuery = "SELECT  * FROM " + TABLE_CLASSES;
        Cursor cursor = db.rawQuery(selectQuery, null);
        // looping through all rows and adding to list
        while (cursor.moveToNext()) {
            Class c = new Class();
            c.setID(cursor.getInt(0));
            c.setName(cursor.getString(1));
            ClassList.add(c);
        }
        // return quest list
        return ClassList;
    }
    public List<Category> getAllCategories() {
        SQLiteDatabase db=this.getReadableDatabase();

        List<Category> CategoryList = new ArrayList<Category>();
        // Select All Query
        String selectQuery = "SELECT  * FROM " + TABLE_CATEGORIES;
        Cursor cursor = db.rawQuery(selectQuery, null);
        // looping through all rows and adding to list
        while (cursor.moveToNext()) {
            Category c = new Category();
            c.setID(cursor.getInt(0));
            c.setName(cursor.getString(1));
            c.setWorth(cursor.getDouble(2));
            c.setClassName(cursor.getString(3));
            CategoryList.add(c);
        }
        // return quest list
        return CategoryList;
    }
    public List<Assignment> getAllAssignments() {
        SQLiteDatabase db=this.getReadableDatabase();

        List<Assignment> AssignmentList = new ArrayList<Assignment>();
        // Select All Query
        String selectQuery = "SELECT  * FROM " + TABLE_ASSIGNMENTS;
        Cursor cursor = db.rawQuery(selectQuery, null);
        // looping through all rows and adding to list
        while (cursor.moveToNext()) {
            Assignment a = new Assignment();
            a.setID(cursor.getInt(0));
            a.setAssignmentname(cursor.getString(1));
            a.setClassname(cursor.getString(2));
            a.setCategoryname(cursor.getString(3));
            a.setEarnedPoints(cursor.getDouble(4));
            a.setTotalpoints(cursor.getDouble(5));
            AssignmentList.add(a);
        }
        // return quest list
        return AssignmentList;
    }

    public Integer deleteFromAssignments(String id){
        SQLiteDatabase db = this.getReadableDatabase();
        return db.delete(TABLE_ASSIGNMENTS,"assignmentid = ?", new String[] {id});

    }
    public Integer deleteFromCategories(String id){
        SQLiteDatabase db = this.getReadableDatabase();
        return db.delete(TABLE_CATEGORIES,"categoryid = ?", new String[] {id});

    }
    public Integer deleteFromClasses(String id){
        SQLiteDatabase db = this.getReadableDatabase();
        return db.delete(TABLE_CLASSES,"classid = ?", new String[] {id});

    }
}
