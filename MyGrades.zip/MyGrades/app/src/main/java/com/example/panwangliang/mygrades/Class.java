package com.example.panwangliang.mygrades;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by Jason Pan on 12/29/2017.
 */

public class Class {
    private String name;
    private List<Category> categorylist;
    private double total;
    private double worth;
    private int ID;

    public Class(List<Category> list,String n){
        name=n;
        categorylist=list;
    }
    public Class(){
        ID = 0;
        name ="";
        total=0;
        worth=0;
        categorylist = new ArrayList<Category>();
    }




    public void setID(int i){ ID= i;}
    public void setCategorylist(List<Category> list){
        categorylist= list;
    }
    public void setName(String n){
        name = n;
    }
    public void setTotal(double t){
        total = t;
    }
    public void setWorth(double w){
        worth=w;
    }
    public List<Category> getcategorylist(){
        return categorylist;
    }

    public void setWorthTotal(){
        double grade =0;
        double totalworth = 0;
        for(int i=0;i<categorylist.size();i++){
            grade+=categorylist.get(i).returnCategoryTotal();
            totalworth+=categorylist.get(i).getWorth();
        }
        total = grade;
        worth = totalworth;
    }
    public String getClassName(){
        return name;
    }
    public double returnGrade(){
        setWorthTotal();
        double x =total/worth;
        return (double)Math.round( x*100 )/100;

    }
    public int getID() { return ID;}

    public int returnRequiredGrade(int possible, String categoryname,int grade) {
        int categoryindex = -1;
        for (int i = 0; i < categorylist.size(); i++) {

            if (categorylist.get(i).getCategoryName().equals(categoryname)) {
                categoryindex = i;
            }
        }

        if ((double) grade >= Math.round(returnGrade())) {


            double wantgrade = (double) grade - 0.5;
            setWorthTotal();
            double needgrade = (((wantgrade / 100) * (worth * 100)) - total) / categorylist.get(categoryindex).getWorth();
            double newhighesttotalearned = categorylist.get(categoryindex).getTotalEarnedPoints() + possible;
            double newtotalpossible = categorylist.get(categoryindex).getTotalPoints() + possible;
            double oldtotalearned = categorylist.get(categoryindex).getTotalEarnedPoints();
            double oldtotalpossible = categorylist.get(categoryindex).getTotalPoints();
            if ((newhighesttotalearned / newtotalpossible) * 100 - (oldtotalearned / oldtotalpossible) * 100 < needgrade) {
                return -1;
            } else {
                double x = ((((needgrade + oldtotalearned / oldtotalpossible * 100) * newtotalpossible) / 100) - oldtotalearned);
                return ((int) Math.floor(x)) + 1;
            }


        }
        if ((double)grade < Math.round(returnGrade())) {
            double wantgrade = (double) grade + .49;
            setWorthTotal();
            double needgrade = (((wantgrade / 100) * (worth * 100)) - total) / categorylist.get(categoryindex).getWorth();
            needgrade= needgrade*-1;
            double newhighesttotalearned = categorylist.get(categoryindex).getTotalEarnedPoints() + possible;
            double newtotalpossible = categorylist.get(categoryindex).getTotalPoints() + possible;
            double oldtotalearned = categorylist.get(categoryindex).getTotalEarnedPoints();
            double oldtotalpossible = categorylist.get(categoryindex).getTotalPoints();
            if ((oldtotalearned / oldtotalpossible) * 100- (oldtotalearned / newtotalpossible) * 100  < needgrade) {
                return -1;
            } else {
                double x = ((((needgrade - oldtotalearned / oldtotalpossible * 100) * (newtotalpossible*-1)) / 100) - oldtotalearned);
                return ((int) Math.floor(x));
            }
        }
        return -1;
    }

}
