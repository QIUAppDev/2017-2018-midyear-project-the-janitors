package com.example.panwangliang.mygrades;




import java.util.ArrayList;
import java.util.List;

/**
 * Created by Jason Pan on 12/29/2017.
 */

public class Category {
    private String name;
    private List<Assignment> assignmentlist;
    private double worth;
    private double totalp,totalep;
    private String classname;
    private int ID;

    public Category(String n,List<Assignment> list,double w, String cname){
        name=n;
        assignmentlist=list;
        worth=w;
        classname = cname;
    }

    public Category(){
        name = "";
        worth = 0;
        classname = "";
        ID = 0;
        assignmentlist = new ArrayList<Assignment>();
    }
    public void setAssignmentlist(List<Assignment> list){
        assignmentlist=list;
    }


    public void setID(int i){ ID= i;}
    public void setName(String n){
        name = n;
    }
    public void setWorth(Double w){
        worth = w;
    }
    public void setClassName(String n){
        classname = n;
    }
    public double returnCategoryTotal(){
        double totalpoints =0;
        double totalearnedpoints=0;
        for(int i=0;i<assignmentlist.size();i++){
            totalpoints+=assignmentlist.get(i).getTotalpoints();
            totalearnedpoints+=assignmentlist.get(i).getEarnedpoints();
        }
        totalp=totalpoints;
        totalep=totalearnedpoints;
        double percentage = (totalearnedpoints/totalpoints)*100;

        return ( (double)Math.round(percentage*100)/100*worth)  ;
    }
    public double getWorth(){
        return worth;
    }
    public int getID() { return ID;}
    public double getTotalPoints(){
        return totalp;
    }
    public double getTotalEarnedPoints(){
        return totalep;
    }
    public String getCategoryName(){
        return name;
    }
    public String getClassname(){return classname;}
    public List<Assignment> getAssignmentlist(){
        return assignmentlist;
    }




}
