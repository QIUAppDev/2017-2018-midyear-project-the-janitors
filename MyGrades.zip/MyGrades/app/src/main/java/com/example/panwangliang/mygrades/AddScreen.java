package com.example.panwangliang.mygrades;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class AddScreen extends AppCompatActivity {

    private EditText categoryname, assignmentname, classname, whatclass,whatcategory,categoryworth,earnedpoints,possiblepoints;
    private Button addCategory, addAssignment, addClass, add;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_screen);
        initialize();

    }
    public void initialize(){
        categoryname = findViewById(R.id.categoryName);
        assignmentname = findViewById(R.id.AssignmentName);
        classname = findViewById(R.id.className);
        whatclass = findViewById(R.id.whichClass);
        whatcategory = findViewById(R.id.whichCategory);
        categoryworth = findViewById(R.id.categoryWorth);
        earnedpoints = findViewById(R.id.totalEarned);
        possiblepoints = findViewById(R.id.totalPossible);
        addCategory = findViewById(R.id.addCategory);
        addAssignment = findViewById(R.id.addAssignment);
        addClass = findViewById(R.id.addClass);
        add = findViewById(R.id.addField);
    }

    public void showClass(View view){
        setInvisible();
        classname.setVisibility(View.VISIBLE);
        add.setVisibility(View.VISIBLE);
    }
    public void showAssignment(View view){
        setInvisible();
        assignmentname.setVisibility(View.VISIBLE);
        whatclass.setVisibility(View.VISIBLE);
        whatcategory.setVisibility(View.VISIBLE);
        earnedpoints.setVisibility(View.VISIBLE);
        possiblepoints.setVisibility(View.VISIBLE);
        add.setVisibility(View.VISIBLE);

    }
    public void showCategory(View view){
        setInvisible();
        categoryname.setVisibility(View.VISIBLE);
        whatclass.setVisibility(View.VISIBLE);
        categoryworth.setVisibility(View.VISIBLE);
        add.setVisibility(View.VISIBLE);

    }

    public void setInvisible(){
        categoryname.setVisibility((View.INVISIBLE));
        assignmentname.setVisibility((View.INVISIBLE));
        classname.setVisibility((View.INVISIBLE));
        whatclass.setVisibility((View.INVISIBLE));
        whatcategory.setVisibility((View.INVISIBLE));
        categoryworth.setVisibility((View.INVISIBLE));
        earnedpoints.setVisibility((View.INVISIBLE));
        possiblepoints.setVisibility((View.INVISIBLE));
        add.setVisibility((View.INVISIBLE));

    }

    public void addField(View view){
        Bundle bundle = new Bundle();
        Intent intent = new Intent(this,MainActivity.class);
        if(classname.getVisibility()==View.VISIBLE){
            bundle.putString("type", "class");
            bundle.putString("classname",classname.getText().toString());
            intent.putExtras(bundle);
            startActivity(intent);

        }

        if(assignmentname.getVisibility()==View.VISIBLE){
            bundle.putString("type", "assignment");
            bundle.putString("assignmentname",assignmentname.getText().toString());
            bundle.putString("whatcategory",whatcategory.getText().toString());
            bundle.putString("whatclass",whatclass.getText().toString());
            bundle.putDouble("possiblepoints",Double.parseDouble(possiblepoints.getText().toString()));
            bundle.putDouble("earnedpoints",Double.parseDouble(earnedpoints.getText().toString()));
            intent.putExtras(bundle);
            startActivity(intent);
        }

        if(categoryname.getVisibility()==View.VISIBLE){
            Category c = new Category();
            c.setName(categoryname.getText().toString());
            c.setClassName(whatclass.getText().toString());
            c.setWorth(Double.parseDouble(categoryworth.getText().toString()));
            bundle.putString("type", "category");
            bundle.putString("categoryname", categoryname.getText().toString());
            bundle.putString("whatclass", whatclass.getText().toString());
            bundle.putDouble("categoryworth",Double.parseDouble(categoryworth.getText().toString()));
            intent.putExtras(bundle);
            startActivity(intent);
        }
    }
}
