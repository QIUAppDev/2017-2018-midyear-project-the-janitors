package com.example.panwangliang.mygrades;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class CalculateScreen extends AppCompatActivity {

    private TextView test, wantgrade, needgrade;
    private ArrayList<Integer> intarr;
    private int max;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculate_screen);
        Bundle bundle = getIntent().getExtras();
        intarr= bundle.getIntegerArrayList("intlist");
        max = bundle.getInt("max");
        wantgrade = findViewById(R.id.grade);
        needgrade = findViewById(R.id.need);
        wantgrade.setText("Want Grade: "+0+"/100" );
        int need = intarr.get(0);
        if(need <= -1 || need>max){
            needgrade.setText("Impossible");

        }
        if(0<=need && need<=max ){
            needgrade.setText("You will need a " + intarr.get(0)+"/"+max);

        }
        SeekBar seekbar = findViewById(R.id.seekBar);
        seekbar.setOnSeekBarChangeListener(
                new SeekBar.OnSeekBarChangeListener() {
                    int progress;
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                        progress=i;
                        wantgrade.setText("Want Grade: "+(i+1)+"/100");
                        int need = intarr.get(i);
                        if(need <= -1 || need>max){
                            needgrade.setText("Impossible");

                        }
                        if(0<=need && need<=max ){
                            needgrade.setText("You will need a " + intarr.get(i)+"/"+max);

                        }



                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {

                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                        wantgrade.setText("Want Grade: "+(progress+1)+"/100");
                        int need = intarr.get(progress);
                        if(need == -1 || need>max){
                            needgrade.setText("Impossible");

                        }
                        if(0<=need && need<=max ){
                            needgrade.setText("You will need a " + intarr.get(progress)+"/"+max);

                        }


                    }
                }
        );

    }
}
