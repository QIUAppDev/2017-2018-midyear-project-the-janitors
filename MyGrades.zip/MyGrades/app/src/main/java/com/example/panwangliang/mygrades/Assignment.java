package com.example.panwangliang.mygrades;

/**
 * Created by Jason Pan on 12/29/2017.
 */

public class Assignment {
    private int ID;
    private double totalpoints;
    private double earnedpoints;
    private String categoryname;
    private String classname;
    private String assignmentname;

    public Assignment(double tot,double earn, String catname, String cname, String aname){
        totalpoints=tot;
        earnedpoints=earn;
        categoryname=catname;
        classname=cname;
        assignmentname=aname;
    }
    public Assignment(){
        ID=0;
        totalpoints = 0;
        earnedpoints= 0;
        categoryname = "";
        classname = "";
        assignmentname = "";
    }
    public void setID(int i){ ID= i;}
    public void setTotalpoints(double tp){
        totalpoints=tp;
    }
    public void setEarnedPoints(double ep){
        earnedpoints=ep;
    }
    public void setCategoryname(String catname){
        categoryname=catname;
    }
    public void setClassname(String cname){
        classname=cname;
    }
    public void setAssignmentname(String aname){
        assignmentname=aname;
    }




    public int getID() { return ID;}
    public double getTotalpoints(){
        return totalpoints;
    }
    public double getEarnedpoints() {
        return earnedpoints;
    }
    public String getCategoryName(){ return categoryname;}
    public String getClassName(){return classname;}
    public String getAssignmentname(){return assignmentname;}
}
